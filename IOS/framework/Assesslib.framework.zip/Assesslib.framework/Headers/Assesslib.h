
#import <Foundation/Foundation.h>

@protocol AssesslibDelegate <NSObject>

@required
-(void)AssesslibCallBack:(nonnull NSString *) message;

@end

@interface Assesslib : NSObject

+(nonnull Assesslib *)AssesslibShareInstance;

@property (nonatomic, weak) id <AssesslibDelegate> assesslibDelegate;

-(void)AssesslibInitWithDebug:(BOOL)model;
-(void)showLoginPanel;
-(void)createRole:(nonnull NSString *)roleId withRoleName:(nullable NSString *)roleName withRoleType:(nullable NSString *)roleType withRoleGender:(int)roleGender withRoleLevel:(int)roleLevel withRoleCreateTime:(nullable NSString *)roleCreateTime;
-(void)enterGame:(nonnull NSString *)roleId withRoleName:(nullable NSString *)roleName withRoleType:(nullable NSString *)roleType withRoleGender:(int)roleGender withRoleLevel:(int)roleLevel withVipLevel:(int)vipLevel withRoleCreateTime:(nullable NSString *)roleCreateTime;
-(void)Logout;

@end
