
#import <Foundation/Foundation.h>

@interface Assesslib : NSObject

+(nonnull Assesslib *)AssesslibShareInstance;


-(void)AssesslibInitWithDebug:(BOOL)model;
-(void)showLoginPanel;
-(void)createRole:(nonnull NSString *)roleId withRoleName:(nullable NSString *)roleName withRoleType:(nullable NSString *)roleType withRoleGender:(int)roleGender withRoleLevel:(int)roleLevel withRoleCreateTime:(nullable NSString *)roleCreateTime;
-(void)enterGame:(nonnull NSString *)roleId withRoleName:(nullable NSString *)roleName withRoleType:(nullable NSString *)roleType withRoleGender:(int)roleGender withRoleLevel:(int)roleLevel withVipLevel:(int)vipLevel withRoleCreateTime:(nullable NSString *)roleCreateTime;
-(void)Logout;

@end
