//
//  SceneDelegate.h
//  assesslibDemo
//
//  Created by ggalt on 2020/5/23.
//  Copyright © 2020 ggalt. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

