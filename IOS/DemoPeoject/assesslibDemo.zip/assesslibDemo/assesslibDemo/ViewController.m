//
//  ViewController.m
//  assesslibDemo
//
//  Created by ggalt on 2020/5/23.
//  Copyright © 2020 ggalt. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()<AssesslibDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (IBAction)forInit:(id)sender {
    [[Assesslib AssesslibShareInstance]AssesslibInitWithDebug:YES];
    [Assesslib AssesslibShareInstance].assesslibDelegate = self;
}

- (IBAction)login:(id)sender {
    [[Assesslib AssesslibShareInstance]showLoginPanel];
}

- (IBAction)role:(id)sender {
    [[Assesslib AssesslibShareInstance]createRole:@"3759506187" withRoleName:@"璐璐" withRoleType:@"辅助" withRoleGender:1 withRoleLevel:6 withRoleCreateTime:@"202005231644"];
}

- (IBAction)enterGame:(id)sender {
    [[Assesslib AssesslibShareInstance]enterGame:@"3759506187" withRoleName:@"璐璐" withRoleType:@"辅助" withRoleGender:1 withRoleLevel:6 withVipLevel:30 withRoleCreateTime:@"202005231644"];
}

- (IBAction)logout:(id)sender {
    [[Assesslib AssesslibShareInstance]Logout];
}

-(void)AssesslibCallBack:(nonnull NSString *) message
{
    NSLog(@"CallBack message = %@",message);
}
@end
