//
//  ViewController.h
//  assesslibDemo
//
//  Created by ggalt on 2020/5/23.
//  Copyright © 2020 ggalt. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Assesslib/Assesslib.h"

@interface ViewController : UIViewController<AssesslibDelegate>


@end

